<div align="center">

<img src="screenshots/logo.jpg" width="140" alt="Navvora logo" style="border-radius:28px"/>

# N A V V O R A

### 🎬 Your Movies, Series & Anime — All in One Beautiful App

[![Latest Release](https://img.shields.io/badge/Latest%20Release-v1.0.1--stable-62CFFF?style=for-the-badge&logo=github&logoColor=white)](../../releases/latest)
[![Platform](https://img.shields.io/badge/Platform-Android-3DDC84?style=for-the-badge&logo=android&logoColor=white)](../../releases/latest)
[![Kotlin](https://img.shields.io/badge/Built%20with-Kotlin-7F52FF?style=for-the-badge&logo=kotlin&logoColor=white)](https://kotlinlang.org/)
[![Open Source](https://img.shields.io/badge/Open%20Source-Yes-brightgreen?style=for-the-badge)](https://github.com/TheARCreactorGUY/Euthopiar-)

<br/>

[![Download APK](https://img.shields.io/badge/⬇%20%20DOWNLOAD%20APK-62CFFF?style=for-the-badge&logoColor=white&labelColor=141414)](../../releases/latest)
[![All Releases](https://img.shields.io/badge/📦%20%20ALL%20RELEASES-141414?style=for-the-badge&logoColor=white&labelColor=62CFFF)](../../releases)

</div>

---

> Navvora is a personal UI rebrand based on the original [Euthopiar project](https://github.com/TheARCreactorGUY/Euthopiar-). Core playback and plugin features are retained.

<div align="center">

# 🔌 NUVIO PLUGINS — BUILT-IN COMPATIBILITY

## ✅ Navvora works with Nuvio Plugins out of the box!

### 👇 Copy this plugin manifest link and add it in the app 👇

```
https://raw.githubusercontent.com/TheARCreactorGUY/Plugins/main/manifest.json
```

[![Plugin Manifest](https://img.shields.io/badge/🔗%20OPEN%20PLUGIN%20MANIFEST-62CFFF?style=for-the-badge)](https://raw.githubusercontent.com/TheARCreactorGUY/Plugins/main/manifest.json)

</div>

---

## 📱 Platform Availability

| Platform | Status |
|---|---|
| 📱 **Android Smartphone App** | ✅ **Available now** — [Download](../../releases/latest) |
| 📺 **Android TV App** | 🚧 **Coming soon** — stay tuned! |

## 📖 What is Navvora?

**Navvora** is a modern, Netflix-style Android app for discovering and watching **movies, TV series and anime**. It has a clean dark design, big cinematic posters, and a smooth, easy-to-use interface — so you can find something to watch in seconds.

## ✨ Features

| | Feature | Description |
|---|---|---|
| 🏠 | **Cinematic Home** | Big featured banner, *Top 10 Today*, *Trending Today* and genre rows |
| 🔍 | **Smart Search** | Search movies, series & anime with filters for type, genre and year |
| 🎞️ | **Rich Details Page** | Ratings (IMDb / Rotten Tomatoes), runtime, cast & crew, similar titles |
| 📥 | **Downloads** | Save titles to watch offline |
| 🔖 | **Watchlist & Playlists** | Save favourites and organise them your way |
| ▶️ | **Continue Watching** | Pick up exactly where you left off |
| 🔌 | **Nuvio Plugins Compatible** | Built-in support for Nuvio plugins |
| 🌑 | **Dark, Modern UI** | Smooth navigation with a floating bottom bar |

## 📸 Screenshots

<div align="center">

| Home | Trending | Details |
|:---:|:---:|:---:|
| <img src="screenshots/home.jpg" width="250"/> | <img src="screenshots/trending.jpg" width="250"/> | <img src="screenshots/details.jpg" width="250"/> |

| Search | Library |
|:---:|:---:|
| <img src="screenshots/search.jpg" width="250"/> | <img src="screenshots/library.jpg" width="250"/> |

</div>

## 📲 Download & Install

1. Go to the **[Latest Release](../../releases/latest)** page.
2. Download the **`.apk`** file.
3. Open it on your Android phone and allow *"Install from unknown sources"* if asked.
4. Open Navvora and enjoy! 🍿
5. *(Optional)* Add the Nuvio plugin manifest link above to unlock more sources.

<div align="center">

[![Download Latest](https://img.shields.io/badge/⬇%20%20GET%20v1.0.1--stable-62CFFF?style=for-the-badge)](../../releases/latest)

</div>

## 🛠️ Build From Source

```bash
# Clone your own Navvora repository after uploading this source.
# Then build with: ./gradlew assembleDebug
./gradlew assembleDebug
```

The APK will be in `app/build/outputs/apk/debug/`.

## ⚠️ Disclaimer

Navvora does not host or store any media. Content is provided by third-party plugins/sources added by the user. Please respect copyright laws in your country.

## ☕ Support the Project

Navvora is free and open source. If you enjoy it, you can support its development by buying me a coffee — it helps keep the app alive and growing!

<div align="center">

[![Buy Me A Coffee](https://img.shields.io/badge/☕%20%20BUY%20ME%20A%20COFFEE-FFDD00?style=for-the-badge&logoColor=black&labelColor=000000)](https://buymeacoffee.com/TheARCreactorGUY)

<a href="https://buymeacoffee.com/TheARCreactorGUY"><img src="screenshots/bmc-qr.png" width="200" alt="Buy Me A Coffee QR code"/></a>

*Scan the QR code or click the button above.*

</div>

## ⭐ Star the Repo

Can't donate? Give the project a **star ⭐** on GitHub — it really helps too!

<div align="center">

Made with ❤️ by [TheARCreactorGUY](https://github.com/TheARCreactorGUY)

</div>
