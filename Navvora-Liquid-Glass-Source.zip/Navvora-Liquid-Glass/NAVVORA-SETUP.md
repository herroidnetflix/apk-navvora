# Navvora Liquid Glass — setup notes

## Build an APK with GitHub Actions

1. Create a new GitHub repository for your personal Navvora source.
2. Upload the **contents** of this ZIP (the files inside the project folder) to the repository root.
3. Open **Actions** and run **Navvora Staging CI** manually, or push to `main`, `master`, or `develop`.
4. When the workflow finishes, open the run and download the `navvora-debug-apk` artifact.
5. Unzip the artifact to get the debug APK.

The workflow runs unit tests and `assembleDebug`. The first build on GitHub can take several minutes while Gradle downloads dependencies.

## Self-update source

The original project includes an in-app GitHub release checker. To make that checker follow your Navvora releases instead of the upstream Euthopiar releases, edit `AppUpdateConfig` in:

`app/src/main/java/com/euthopiar/data/update/AppUpdateManager.kt`

Set `GITHUB_OWNER` and `GITHUB_REPO` to your own GitHub username and repository name after you create the repository. This is intentionally left pointing at the upstream source until your personal repository exists.

## Compatibility choices

- The launcher label, visible wordmarks, onboarding, About screen, share text, and app-facing messages use **Navvora**.
- The application ID and Kotlin package remain `com.euthopiar` to avoid a broad package migration that could break existing integrations. Android therefore treats this as the same package as the original app; uninstall the original first if Android reports a signing conflict.
- Internal preferences and database names are kept stable so the app does not silently lose existing local settings or library data.
- Configuration backups are exported as Navvora backups, while legacy Euthopiar backups remain importable.

## Validation status

The source was statically inspected and XML resources were checked. A local Gradle build could not be completed in the editing environment because it could not reach `services.gradle.org` to download the Gradle wrapper distribution. Use GitHub Actions to perform the online build and tests.
