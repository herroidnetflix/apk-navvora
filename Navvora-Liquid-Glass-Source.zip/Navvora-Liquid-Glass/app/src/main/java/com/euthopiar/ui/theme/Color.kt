package com.euthopiar.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class AppSurfaces(
    val scrim: Color,
    val glassTint: Color,
    val outline: Color,
    val isAmoled: Boolean,
)

val LocalAppSurfaces = staticCompositionLocalOf<AppSurfaces> {
    AppSurfaces(
        scrim = Color(0xA6081020),
        glassTint = Color(0xC91A2540),
        outline = Color(0x35D8E8FF),
        isAmoled = false
    )
}

// ============================================================================
// Semantic Color Tokens (Calm Dark Design System)
// ============================================================================

val Background = Color(0xE8080B14)
val SurfaceLow = Color(0xD9141C2E)     // Translucent midnight-blue glass cards
val SurfaceMid = Color(0xE61A2540)     // Frosted indigo glass sheets and inputs
val SurfaceHigh = Color(0xF02B3A59)    // Lifted glass and selected pills
val OverlayScrim = Color(0xA6081020)   // Deep blue glass scrim
val Outline = Color(0x35D8E8FF)        // Cool refractive hairline border
val BorderSubtle = Outline


val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB8C6DE)  // WCAG AA on Background (>= 4.5:1)
val TextTertiary = Color(0xFF8292B0)   // Captions, subtle metadata (>= 3:1)

val Accent = Color(0xFF75D9FF)         // Liquid-glass ice-cyan accent
val AccentViolet = Color(0xFFA99BFF)
val AccentRose = Color(0xFFFF9BCB)
val Success = Color(0xFF56E6B0)
val Warning = Color(0xFFFF9F0A)
val Error = Color(0xFFFF453A)

// Signal Health & Player Modernization Tokens
val SignalGood = Color(0xFF3DDC97)
val SignalFair = Color(0xFFF5B83D)
val SignalPoor = Color(0xFFFF5A5F)
val GoldAccent = Color(0xFFD4AF37)

val SpecularBorderBrush = androidx.compose.ui.graphics.Brush.verticalGradient(
    colors = listOf(
        Color.White.copy(alpha = 0.22f),
        Color.White.copy(alpha = 0.04f)
    )
)

// Skeleton Loading Tokens
val SkeletonBase = Color(0xFF10182A)
val SkeletonHighlight = Color(0xFF202E48)

// Brand Rating Tokens
val ImdbGold = Color(0xFFF5C518)
val RottenTomatoesFresh = Color(0xFFFA320A)
val RottenTomatoesRotten = Color(0xFF00B020)


// Overlays (Glass/blur reserved only for floating navigation, player HUD, sheets over video)
val GlassSurfaceNavbar = Color(0xC91A2540)
val GlassBorder = Color(0x55D7E8FF)
val RefractiveGlassBorder = Color(0x66B9C8FF)

// ============================================================================
// Deprecated Legacy Aliases (Supported during incremental screen migrations)
// ============================================================================
@Deprecated("Use Background instead", ReplaceWith("Background"))
val VelvetBlack = Background

@Deprecated("Use SurfaceLow instead", ReplaceWith("SurfaceLow"))
val ObsidianDark = SurfaceLow

@Deprecated("Use SurfaceLow instead", ReplaceWith("SurfaceLow"))
val GlassSurface = SurfaceLow

@Deprecated("Use SurfaceHigh instead", ReplaceWith("SurfaceHigh"))
val GlassSurfacePill = SurfaceHigh

@Deprecated("Use TextPrimary instead", ReplaceWith("TextPrimary"))
val PureWhite = TextPrimary

@Deprecated("Use Background instead", ReplaceWith("Background"))
val PureBlack = Color(0xFF000000)

@Deprecated("Use TextTertiary instead", ReplaceWith("TextTertiary"))
val TextMuted = TextTertiary

@Deprecated("Use Warning or TextPrimary instead", ReplaceWith("Warning"))
val StarGold = Color(0xFFFFD700)

@Deprecated("Use Background instead", ReplaceWith("Background"))
val BackgroundDark = Background

@Deprecated("Use SurfaceLow instead", ReplaceWith("SurfaceLow"))
val SurfaceDark = SurfaceLow

@Deprecated("Use SurfaceMid instead", ReplaceWith("SurfaceMid"))
val SurfaceGlass = SurfaceMid

@Deprecated("Use Outline instead", ReplaceWith("Outline"))
val SurfaceGlassBorder = Outline

@Deprecated("Use Error instead", ReplaceWith("Error"))
val CrimsonAlert = Error

@Deprecated("Use Success instead", ReplaceWith("Success"))
val EmeraldGreen = Success
