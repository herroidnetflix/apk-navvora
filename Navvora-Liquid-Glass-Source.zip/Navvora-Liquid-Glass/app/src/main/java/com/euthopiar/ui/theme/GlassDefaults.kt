package com.euthopiar.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Shared styling constants for frosted-glass surfaces (FloatingNavbar and Hero "More Details" pill).
 */
object GlassDefaults {
    val BlurRadius: Dp = 24.dp
    const val TintAlpha: Float = 0.12f
    val TintColor: Color = Color.White.copy(alpha = TintAlpha)
    const val NoiseFactor: Float = 0.045f

    val BorderBrush: Brush = Brush.verticalGradient(
        listOf(
            Color(0xFFDDF4FF).copy(alpha = 0.48f),
            Color(0xFFB5C9FF).copy(alpha = 0.20f),
            Color.White.copy(alpha = 0.07f)
        )
    )

    val NavbarFallbackColor: Color = Color(0xD91A2540)
    val PillFallbackColor: Color = Color(0xFFB8DFFF).copy(alpha = 0.18f)
}
